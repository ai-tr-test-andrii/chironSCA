import os
import pickle
import sqlite3
import logging
import subprocess
import urllib.request
from flask import Flask, request, redirect, Response, make_response, send_file

app = Flask(__name__)
db_connection = None

# =============================================================================
# CRITICAL: SQL Injection (CWE-89)
# =============================================================================

@app.route("/api/user/get")
def sqli_user_get():
    param = request.args.get("id", "")
    query = f"SELECT id, username, email FROM users WHERE id = {param}"
    cursor = db_connection.cursor()
    cursor.execute(query)
    return Response(str(cursor.fetchall()), mimetype="text/plain")

@app.route("/api/user/search")
def sqli_user_search():
    term = request.args.get("q", "")
    query = "SELECT id, username, email FROM users WHERE username LIKE '%" + term + "%'"
    cursor = db_connection.cursor()
    cursor.execute(query)
    return Response(str(cursor.fetchall()), mimetype="text/plain")

@app.route("/api/user/filter")
def sqli_user_filter():
    val = request.args.get("val", "")
    sort = request.args.get("sort", "id")
    query = "SELECT id, username, email, password FROM users WHERE email = '%s' ORDER BY %s" % (val, sort)
    cursor = db_connection.cursor()
    cursor.execute(query)
    return Response(str(cursor.fetchall()), mimetype="text/plain")

@app.route("/api/user/update", methods=["POST"])
def sqli_user_update():
    rec_id = request.form.get("id", "")
    new_val = request.form.get("value", "")
    query = f"UPDATE users SET username = '{new_val}' WHERE id = {rec_id}"
    cursor = db_connection.cursor()
    cursor.execute(query)
    db_connection.commit()
    return Response("Updated", mimetype="text/plain")

@app.route("/api/product/get")
def sqli_product_get():
    param = request.args.get("id", "")
    query = f"SELECT id, name, price FROM products WHERE id = {param}"
    cursor = db_connection.cursor()
    cursor.execute(query)
    return Response(str(cursor.fetchall()), mimetype="text/plain")

@app.route("/api/product/search")
def sqli_product_search():
    term = request.args.get("q", "")
    query = "SELECT id, name, price FROM products WHERE name LIKE '%" + term + "%'"
    cursor = db_connection.cursor()
    cursor.execute(query)
    return Response(str(cursor.fetchall()), mimetype="text/plain")

@app.route("/api/product/filter")
def sqli_product_filter():
    val = request.args.get("val", "")
    sort = request.args.get("sort", "id")
    query = "SELECT id, name, price, category FROM products WHERE price = '%s' ORDER BY %s" % (val, sort)
    cursor = db_connection.cursor()
    cursor.execute(query)
    return Response(str(cursor.fetchall()), mimetype="text/plain")

@app.route("/api/product/update", methods=["POST"])
def sqli_product_update():
    rec_id = request.form.get("id", "")
    new_val = request.form.get("value", "")
    query = f"UPDATE products SET name = '{new_val}' WHERE id = {rec_id}"
    cursor = db_connection.cursor()
    cursor.execute(query)
    db_connection.commit()
    return Response("Updated", mimetype="text/plain")

@app.route("/api/order/get")
def sqli_order_get():
    param = request.args.get("id", "")
    query = f"SELECT id, user_id, total FROM orders WHERE id = {param}"
    cursor = db_connection.cursor()
    cursor.execute(query)
    return Response(str(cursor.fetchall()), mimetype="text/plain")

@app.route("/api/order/search")
def sqli_order_search():
    term = request.args.get("q", "")
    query = "SELECT id, user_id, total FROM orders WHERE user_id LIKE '%" + term + "%'"
    cursor = db_connection.cursor()
    cursor.execute(query)
    return Response(str(cursor.fetchall()), mimetype="text/plain")

@app.route("/api/order/filter")
def sqli_order_filter():
    val = request.args.get("val", "")
    sort = request.args.get("sort", "id")
    query = "SELECT id, user_id, total, status FROM orders WHERE total = '%s' ORDER BY %s" % (val, sort)
    cursor = db_connection.cursor()
    cursor.execute(query)
    return Response(str(cursor.fetchall()), mimetype="text/plain")

@app.route("/api/order/update", methods=["POST"])
def sqli_order_update():
    rec_id = request.form.get("id", "")
    new_val = request.form.get("value", "")
    query = f"UPDATE orders SET user_id = '{new_val}' WHERE id = {rec_id}"
    cursor = db_connection.cursor()
    cursor.execute(query)
    db_connection.commit()
    return Response("Updated", mimetype="text/plain")

@app.route("/api/customer/get")
def sqli_customer_get():
    param = request.args.get("id", "")
    query = f"SELECT id, first_name, email FROM customers WHERE id = {param}"
    cursor = db_connection.cursor()
    cursor.execute(query)
    return Response(str(cursor.fetchall()), mimetype="text/plain")

@app.route("/api/customer/search")
def sqli_customer_search():
    term = request.args.get("q", "")
    query = "SELECT id, first_name, email FROM customers WHERE first_name LIKE '%" + term + "%'"
    cursor = db_connection.cursor()
    cursor.execute(query)
    return Response(str(cursor.fetchall()), mimetype="text/plain")

@app.route("/api/customer/filter")
def sqli_customer_filter():
    val = request.args.get("val", "")
    sort = request.args.get("sort", "id")
    query = "SELECT id, first_name, email, phone FROM customers WHERE email = '%s' ORDER BY %s" % (val, sort)
    cursor = db_connection.cursor()
    cursor.execute(query)
    return Response(str(cursor.fetchall()), mimetype="text/plain")

@app.route("/api/customer/update", methods=["POST"])
def sqli_customer_update():
    rec_id = request.form.get("id", "")
    new_val = request.form.get("value", "")
    query = f"UPDATE customers SET first_name = '{new_val}' WHERE id = {rec_id}"
    cursor = db_connection.cursor()
    cursor.execute(query)
    db_connection.commit()
    return Response("Updated", mimetype="text/plain")

@app.route("/api/employee/get")
def sqli_employee_get():
    param = request.args.get("id", "")
    query = f"SELECT id, name, department FROM employees WHERE id = {param}"
    cursor = db_connection.cursor()
    cursor.execute(query)
    return Response(str(cursor.fetchall()), mimetype="text/plain")

@app.route("/api/employee/search")
def sqli_employee_search():
    term = request.args.get("q", "")
    query = "SELECT id, name, department FROM employees WHERE name LIKE '%" + term + "%'"
    cursor = db_connection.cursor()
    cursor.execute(query)
    return Response(str(cursor.fetchall()), mimetype="text/plain")

@app.route("/api/employee/filter")
def sqli_employee_filter():
    val = request.args.get("val", "")
    sort = request.args.get("sort", "id")
    query = "SELECT id, name, department, salary FROM employees WHERE department = '%s' ORDER BY %s" % (val, sort)
    cursor = db_connection.cursor()
    cursor.execute(query)
    return Response(str(cursor.fetchall()), mimetype="text/plain")

@app.route("/api/employee/update", methods=["POST"])
def sqli_employee_update():
    rec_id = request.form.get("id", "")
    new_val = request.form.get("value", "")
    query = f"UPDATE employees SET name = '{new_val}' WHERE id = {rec_id}"
    cursor = db_connection.cursor()
    cursor.execute(query)
    db_connection.commit()
    return Response("Updated", mimetype="text/plain")

@app.route("/api/invoice/get")
def sqli_invoice_get():
    param = request.args.get("id", "")
    query = f"SELECT id, customer_id, amount FROM invoices WHERE id = {param}"
    cursor = db_connection.cursor()
    cursor.execute(query)
    return Response(str(cursor.fetchall()), mimetype="text/plain")

@app.route("/api/invoice/search")
def sqli_invoice_search():
    term = request.args.get("q", "")
    query = "SELECT id, customer_id, amount FROM invoices WHERE customer_id LIKE '%" + term + "%'"
    cursor = db_connection.cursor()
    cursor.execute(query)
    return Response(str(cursor.fetchall()), mimetype="text/plain")

@app.route("/api/invoice/filter")
def sqli_invoice_filter():
    val = request.args.get("val", "")
    sort = request.args.get("sort", "id")
    query = "SELECT id, customer_id, amount, due_date FROM invoices WHERE amount = '%s' ORDER BY %s" % (val, sort)
    cursor = db_connection.cursor()
    cursor.execute(query)
    return Response(str(cursor.fetchall()), mimetype="text/plain")

@app.route("/api/invoice/update", methods=["POST"])
def sqli_invoice_update():
    rec_id = request.form.get("id", "")
    new_val = request.form.get("value", "")
    query = f"UPDATE invoices SET customer_id = '{new_val}' WHERE id = {rec_id}"
    cursor = db_connection.cursor()
    cursor.execute(query)
    db_connection.commit()
    return Response("Updated", mimetype="text/plain")

@app.route("/api/ticket/get")
def sqli_ticket_get():
    param = request.args.get("id", "")
    query = f"SELECT id, subject, priority FROM tickets WHERE id = {param}"
    cursor = db_connection.cursor()
    cursor.execute(query)
    return Response(str(cursor.fetchall()), mimetype="text/plain")

@app.route("/api/ticket/search")
def sqli_ticket_search():
    term = request.args.get("q", "")
    query = "SELECT id, subject, priority FROM tickets WHERE subject LIKE '%" + term + "%'"
    cursor = db_connection.cursor()
    cursor.execute(query)
    return Response(str(cursor.fetchall()), mimetype="text/plain")

@app.route("/api/ticket/filter")
def sqli_ticket_filter():
    val = request.args.get("val", "")
    sort = request.args.get("sort", "id")
    query = "SELECT id, subject, priority, assignee FROM tickets WHERE priority = '%s' ORDER BY %s" % (val, sort)
    cursor = db_connection.cursor()
    cursor.execute(query)
    return Response(str(cursor.fetchall()), mimetype="text/plain")

@app.route("/api/ticket/update", methods=["POST"])
def sqli_ticket_update():
    rec_id = request.form.get("id", "")
    new_val = request.form.get("value", "")
    query = f"UPDATE tickets SET subject = '{new_val}' WHERE id = {rec_id}"
    cursor = db_connection.cursor()
    cursor.execute(query)
    db_connection.commit()
    return Response("Updated", mimetype="text/plain")

@app.route("/api/account/get")
def sqli_account_get():
    param = request.args.get("id", "")
    query = f"SELECT id, owner, balance FROM accounts WHERE id = {param}"
    cursor = db_connection.cursor()
    cursor.execute(query)
    return Response(str(cursor.fetchall()), mimetype="text/plain")

@app.route("/api/account/search")
def sqli_account_search():
    term = request.args.get("q", "")
    query = "SELECT id, owner, balance FROM accounts WHERE owner LIKE '%" + term + "%'"
    cursor = db_connection.cursor()
    cursor.execute(query)
    return Response(str(cursor.fetchall()), mimetype="text/plain")

@app.route("/api/account/filter")
def sqli_account_filter():
    val = request.args.get("val", "")
    sort = request.args.get("sort", "id")
    query = "SELECT id, owner, balance, account_type FROM accounts WHERE balance = '%s' ORDER BY %s" % (val, sort)
    cursor = db_connection.cursor()
    cursor.execute(query)
    return Response(str(cursor.fetchall()), mimetype="text/plain")

@app.route("/api/account/update", methods=["POST"])
def sqli_account_update():
    rec_id = request.form.get("id", "")
    new_val = request.form.get("value", "")
    query = f"UPDATE accounts SET owner = '{new_val}' WHERE id = {rec_id}"
    cursor = db_connection.cursor()
    cursor.execute(query)
    db_connection.commit()
    return Response("Updated", mimetype="text/plain")

@app.route("/api/payment/get")
def sqli_payment_get():
    param = request.args.get("id", "")
    query = f"SELECT id, order_id, amount FROM payments WHERE id = {param}"
    cursor = db_connection.cursor()
    cursor.execute(query)
    return Response(str(cursor.fetchall()), mimetype="text/plain")

@app.route("/api/payment/search")
def sqli_payment_search():
    term = request.args.get("q", "")
    query = "SELECT id, order_id, amount FROM payments WHERE order_id LIKE '%" + term + "%'"
    cursor = db_connection.cursor()
    cursor.execute(query)
    return Response(str(cursor.fetchall()), mimetype="text/plain")

@app.route("/api/payment/filter")
def sqli_payment_filter():
    val = request.args.get("val", "")
    sort = request.args.get("sort", "id")
    query = "SELECT id, order_id, amount, method FROM payments WHERE amount = '%s' ORDER BY %s" % (val, sort)
    cursor = db_connection.cursor()
    cursor.execute(query)
    return Response(str(cursor.fetchall()), mimetype="text/plain")

@app.route("/api/payment/update", methods=["POST"])
def sqli_payment_update():
    rec_id = request.form.get("id", "")
    new_val = request.form.get("value", "")
    query = f"UPDATE payments SET order_id = '{new_val}' WHERE id = {rec_id}"
    cursor = db_connection.cursor()
    cursor.execute(query)
    db_connection.commit()
    return Response("Updated", mimetype="text/plain")

@app.route("/api/project/get")
def sqli_project_get():
    param = request.args.get("id", "")
    query = f"SELECT id, name, owner_id FROM projects WHERE id = {param}"
    cursor = db_connection.cursor()
    cursor.execute(query)
    return Response(str(cursor.fetchall()), mimetype="text/plain")

@app.route("/api/project/search")
def sqli_project_search():
    term = request.args.get("q", "")
    query = "SELECT id, name, owner_id FROM projects WHERE name LIKE '%" + term + "%'"
    cursor = db_connection.cursor()
    cursor.execute(query)
    return Response(str(cursor.fetchall()), mimetype="text/plain")

@app.route("/api/project/filter")
def sqli_project_filter():
    val = request.args.get("val", "")
    sort = request.args.get("sort", "id")
    query = "SELECT id, name, owner_id, deadline FROM projects WHERE owner_id = '%s' ORDER BY %s" % (val, sort)
    cursor = db_connection.cursor()
    cursor.execute(query)
    return Response(str(cursor.fetchall()), mimetype="text/plain")

@app.route("/api/project/update", methods=["POST"])
def sqli_project_update():
    rec_id = request.form.get("id", "")
    new_val = request.form.get("value", "")
    query = f"UPDATE projects SET name = '{new_val}' WHERE id = {rec_id}"
    cursor = db_connection.cursor()
    cursor.execute(query)
    db_connection.commit()
    return Response("Updated", mimetype="text/plain")

# =============================================================================
# CRITICAL: Command Injection (CWE-78)
# =============================================================================

@app.route("/cmd/ping")
def cmd_ping():
    val = request.args.get("host", "")
    os.system("ping -c 1 " + val)
    return Response("Executed", mimetype="text/plain")

@app.route("/cmd/ping_sub")
def cmd_ping_sub():
    val = request.args.get("host", "")
    result = subprocess.check_output("ping -c 1 " + val, shell=True)
    return Response(result, mimetype="text/plain")

@app.route("/cmd/traceroute")
def cmd_traceroute():
    val = request.args.get("target", "")
    os.system("traceroute " + val)
    return Response("Executed", mimetype="text/plain")

@app.route("/cmd/traceroute_sub")
def cmd_traceroute_sub():
    val = request.args.get("target", "")
    result = subprocess.check_output("traceroute " + val, shell=True)
    return Response(result, mimetype="text/plain")

@app.route("/cmd/dns")
def cmd_dns():
    val = request.args.get("domain", "")
    os.system("nslookup " + val)
    return Response("Executed", mimetype="text/plain")

@app.route("/cmd/dns_sub")
def cmd_dns_sub():
    val = request.args.get("domain", "")
    result = subprocess.check_output("nslookup " + val, shell=True)
    return Response(result, mimetype="text/plain")

@app.route("/cmd/whois")
def cmd_whois():
    val = request.args.get("domain", "")
    os.system("whois " + val)
    return Response("Executed", mimetype="text/plain")

@app.route("/cmd/whois_sub")
def cmd_whois_sub():
    val = request.args.get("domain", "")
    result = subprocess.check_output("whois " + val, shell=True)
    return Response(result, mimetype="text/plain")

@app.route("/cmd/curl")
def cmd_curl():
    val = request.args.get("url", "")
    os.system("curl -s " + val)
    return Response("Executed", mimetype="text/plain")

@app.route("/cmd/curl_sub")
def cmd_curl_sub():
    val = request.args.get("url", "")
    result = subprocess.check_output("curl -s " + val, shell=True)
    return Response(result, mimetype="text/plain")

# =============================================================================
# HIGH: Reflected XSS (CWE-79)
# =============================================================================

@app.route("/page/greet")
def xss_greet():
    val = request.args.get("name", "")
    html = f"<html><body><h1>Hello, {val}!</h1></body></html>"
    return Response(html, mimetype="text/html")

@app.route("/page/profile")
def xss_profile():
    val = request.args.get("user", "")
    html = f"<html><body><div class="profile">{val}</div></body></html>"
    return Response(html, mimetype="text/html")

@app.route("/page/error")
def xss_error():
    val = request.args.get("msg", "")
    html = f"<html><body><div class="error">Error: {val}</div></body></html>"
    return Response(html, mimetype="text/html")

@app.route("/page/title")
def xss_title():
    val = request.args.get("text", "")
    html = f"<html><body><title>{val}</title></body></html>"
    return Response(html, mimetype="text/html")

@app.route("/page/comment")
def xss_comment():
    val = request.args.get("body", "")
    html = f"<html><body><p class="comment">{val}</p></body></html>"
    return Response(html, mimetype="text/html")

@app.route("/page/search_result")
def xss_search_result():
    val = request.args.get("q", "")
    html = f"<html><body><span>Results for: {val}</span></body></html>"
    return Response(html, mimetype="text/html")

@app.route("/page/welcome")
def xss_welcome():
    val = request.args.get("username", "")
    html = f"<html><body><h2>Welcome back, {val}</h2></body></html>"
    return Response(html, mimetype="text/html")

@app.route("/page/alert")
def xss_alert():
    val = request.args.get("message", "")
    html = f"<html><body><div class="alert">{val}</div></body></html>"
    return Response(html, mimetype="text/html")

# =============================================================================
# HIGH: Path Traversal (CWE-22)
# =============================================================================

@app.route("/files/document")
def path_document():
    fname = request.args.get("name", "")
    with open("/var/data/" + fname, "r") as f:
        content = f.read()
    return Response(content, mimetype="text/plain")

@app.route("/files/logfile")
def path_logfile():
    fname = request.args.get("name", "")
    with open("/var/logs/" + fname, "r") as f:
        content = f.read()
    return Response(content, mimetype="text/plain")

@app.route("/files/config")
def path_config():
    fname = request.args.get("name", "")
    with open("/etc/app/" + fname, "r") as f:
        content = f.read()
    return Response(content, mimetype="text/plain")

@app.route("/files/template")
def path_template():
    fname = request.args.get("name", "")
    with open("/var/templates/" + fname, "r") as f:
        content = f.read()
    return Response(content, mimetype="text/plain")

@app.route("/files/report")
def path_report():
    fname = request.args.get("name", "")
    with open("/var/reports/" + fname, "r") as f:
        content = f.read()
    return Response(content, mimetype="text/plain")

@app.route("/files/backup")
def path_backup():
    fname = request.args.get("name", "")
    with open("/var/backups/" + fname, "r") as f:
        content = f.read()
    return Response(content, mimetype="text/plain")

# =============================================================================
# HIGH: Server-Side Request Forgery (CWE-918)
# =============================================================================

@app.route("/net/fetch")
def ssrf_fetch():
    url = request.args.get("url", "")
    resp = urllib.request.urlopen(url)
    return Response(resp.read(), mimetype="text/plain")

@app.route("/net/proxy")
def ssrf_proxy():
    url = request.args.get("url", "")
    resp = urllib.request.urlopen(url)
    return Response(resp.read(), mimetype="text/plain")

@app.route("/net/preview")
def ssrf_preview():
    url = request.args.get("url", "")
    resp = urllib.request.urlopen(url)
    return Response(resp.read(), mimetype="text/plain")

@app.route("/net/webhook")
def ssrf_webhook():
    url = request.args.get("url", "")
    resp = urllib.request.urlopen(url)
    return Response(resp.read(), mimetype="text/plain")

# =============================================================================
# HIGH: Deserialization of Untrusted Data (CWE-502)
# =============================================================================

@app.route("/data/import_data", methods=["POST"])
def deser_import_data():
    raw = request.get_data()
    data = pickle.loads(raw)
    return Response(f"Loaded {len(data)} items", mimetype="text/plain")

@app.route("/data/restore", methods=["POST"])
def deser_restore():
    raw = request.get_data()
    data = pickle.loads(raw)
    return Response(f"Loaded {len(data)} items", mimetype="text/plain")

@app.route("/data/load_session", methods=["POST"])
def deser_load_session():
    raw = request.get_data()
    data = pickle.loads(raw)
    return Response(f"Loaded {len(data)} items", mimetype="text/plain")

# =============================================================================
# MEDIUM: Open Redirect (CWE-601)
# =============================================================================

@app.route("/redirect")
def open_redirect():
    url = request.args.get("url", "/")
    return redirect(url)

# =============================================================================
# MEDIUM: Log Forging (CWE-117)
# =============================================================================

@app.route("/api/action")
def log_action():
    action = request.args.get("action", "")
    user = request.args.get("user", "")
    logging.info(f"User {user} performed action: {action}")
    return Response("Action logged", mimetype="text/plain")

# =============================================================================
# MEDIUM: Header Manipulation (CWE-113)
# =============================================================================

@app.route("/api/set-header")
def set_header():
    value = request.args.get("lang", "en")
    resp = make_response("OK")
    resp.headers["X-Custom-Lang"] = value
    return resp

# =============================================================================
# Initialization
# =============================================================================

def init_db():
    global db_connection
    db_connection = sqlite3.connect(":memory:", check_same_thread=False)
    cursor = db_connection.cursor()
    cursor.execute("CREATE TABLE users (id INTEGER PRIMARY KEY, username TEXT, email TEXT, password TEXT, role TEXT)")
    cursor.execute("INSERT INTO users VALUES (1, 'admin', 'admin@test.com', 'admin123', 'admin')")
    cursor.execute("INSERT INTO users VALUES (2, 'user1', 'user1@test.com', 'pass123', 'user')")
    db_connection.commit()


if __name__ == "__main__":
    init_db()
    app.run(host="0.0.0.0", port=8080, debug=True)
