import os
import pickle
import sqlite3
import logging
import subprocess
import urllib.request
from flask import Flask, request, redirect, Response, make_response, send_file

app = Flask(__name__)

db_connection = None


# =============================================================================
# CRITICAL: SQL Injection (CWE-89)
# =============================================================================

@app.route("/api/user")
def get_user():
    """SQL Injection via f-string interpolation"""
    user_id = request.args.get("id", "")
    query = f"SELECT id, username, email FROM users WHERE id = {user_id}"
    try:
        cursor = db_connection.cursor()
        cursor.execute(query)
        rows = cursor.fetchall()
        return Response(str(rows), mimetype="text/plain")
    except Exception as e:
        logging.error(f"Error: {e}")
        return Response("Database error", status=500)


@app.route("/api/search")
def search_users():
    """SQL Injection via string concatenation"""
    term = request.args.get("q", "")
    query = "SELECT id, username, email FROM users WHERE username LIKE '%" + term + "%'"
    try:
        cursor = db_connection.cursor()
        cursor.execute(query)
        rows = cursor.fetchall()
        return Response(str(rows), mimetype="text/plain")
    except Exception as e:
        logging.error(f"Error: {e}")
        return Response("Database error", status=500)


@app.route("/api/login", methods=["POST"])
def login():
    """SQL Injection via % formatting"""
    username = request.form.get("username", "")
    password = request.form.get("password", "")
    query = "SELECT id, role FROM users WHERE username = '%s' AND password = '%s'" % (username, password)
    try:
        cursor = db_connection.cursor()
        cursor.execute(query)
        row = cursor.fetchone()
        if row:
            return Response(f"Welcome, user {row[0]}", mimetype="text/plain")
        return Response("Invalid credentials", status=401)
    except Exception as e:
        logging.error(f"Error: {e}")
        return Response("Database error", status=500)


# =============================================================================
# CRITICAL: Command Injection (CWE-78)
# =============================================================================

@app.route("/api/ping")
def ping_host():
    """Command Injection via os.system"""
    host = request.args.get("host", "")
    os.system("ping -c 1 " + host)
    return Response("Ping executed", mimetype="text/plain")


@app.route("/api/dns")
def dns_lookup():
    """Command Injection via subprocess with shell=True"""
    domain = request.args.get("domain", "")
    result = subprocess.check_output("nslookup " + domain, shell=True)
    return Response(result, mimetype="text/plain")


# =============================================================================
# HIGH: Reflected XSS (CWE-79)
# =============================================================================

@app.route("/page/greet")
def greet():
    """Reflected XSS - user input rendered in HTML response"""
    name = request.args.get("name", "")
    html = f"<html><body><h1>Hello, {name}!</h1></body></html>"
    return Response(html, mimetype="text/html")


@app.route("/page/error")
def error_page():
    """Reflected XSS - error message includes user input"""
    msg = request.args.get("msg", "")
    html = "<html><body><div class='error'>Error: " + msg + "</div></body></html>"
    return Response(html, mimetype="text/html")


# =============================================================================
# HIGH: Path Traversal (CWE-22)
# =============================================================================

@app.route("/api/file")
def read_file():
    """Path Traversal - reading arbitrary files"""
    filename = request.args.get("name", "")
    filepath = os.path.join("/var/data", filename)
    return send_file(filepath)


@app.route("/api/log")
def read_log():
    """Path Traversal - log file access with user input"""
    log_name = request.args.get("log", "")
    with open("/var/logs/" + log_name, "r") as f:
        content = f.read()
    return Response(content, mimetype="text/plain")


# =============================================================================
# MEDIUM: Open Redirect (CWE-601)
# =============================================================================

@app.route("/redirect")
def open_redirect():
    """Open Redirect - redirecting to user-supplied URL"""
    url = request.args.get("url", "/")
    return redirect(url)


# =============================================================================
# MEDIUM: Log Forging / Log Injection (CWE-117)
# =============================================================================

@app.route("/api/action")
def log_action():
    """Log Forging - user input written to log without sanitization"""
    action = request.args.get("action", "")
    user = request.args.get("user", "")
    logging.info(f"User {user} performed action: {action}")
    return Response("Action logged", mimetype="text/plain")


# =============================================================================
# HIGH: Deserialization of Untrusted Data (CWE-502)
# =============================================================================

@app.route("/api/import", methods=["POST"])
def import_data():
    """Unsafe deserialization of user-supplied data"""
    raw = request.get_data()
    data = pickle.loads(raw)
    return Response(f"Imported {len(data)} records", mimetype="text/plain")


# =============================================================================
# HIGH: Server-Side Request Forgery - SSRF (CWE-918)
# =============================================================================

@app.route("/api/fetch")
def fetch_url():
    """SSRF - fetching user-supplied URL from server side"""
    url = request.args.get("url", "")
    response = urllib.request.urlopen(url)
    content = response.read()
    return Response(content, mimetype="text/plain")


# =============================================================================
# MEDIUM: Header Manipulation (CWE-113)
# =============================================================================

@app.route("/api/set-header")
def set_header():
    """Header Manipulation - user input in HTTP response header"""
    value = request.args.get("lang", "en")
    resp = make_response("OK")
    resp.headers["X-Custom-Lang"] = value
    return resp


# =============================================================================
# Initialization
# =============================================================================

def init_db():
    """Initialize database connection"""
    global db_connection
    db_connection = sqlite3.connect(":memory:", check_same_thread=False)
    cursor = db_connection.cursor()
    cursor.execute("CREATE TABLE users (id INTEGER PRIMARY KEY, username TEXT, email TEXT, password TEXT, role TEXT)")
    cursor.execute("INSERT INTO users VALUES (1, 'admin', 'admin@test.com', 'admin123', 'admin')")
    cursor.execute("INSERT INTO users VALUES (2, 'user1', 'user1@test.com', 'pass123', 'user')")
    db_connection.commit()


if __name__ == "__main__":
    init_db()
    # LOW: Debug Enabled - running in debug mode exposes stack traces
    app.run(host="0.0.0.0", port=8080, debug=True)
